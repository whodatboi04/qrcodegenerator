<?php

define('dbhost','localhost');
define('dbuser','xrlozngh_PSBIMUser');
define('dbpass','1953@pcP123');
define('db_name','xrlozngh_PSBIM_DB');



try {
    $conn = new PDO("mysql:host=".dbhost.";dbname=".db_name,dbuser,dbpass);
} catch (PDOException $e) {
    exit("Error".$e->getMessage());
}




if(isset($_GET['seatcode']))
{


    session_start();

    $varSeatCode = $_GET['seatcode'];

    $statement = $conn->prepare("select * from PSBIM_tbl where SeatCode = :seatcode");
    $statement->bindparam(":seatcode",$varSeatCode);
    $statement->execute();
    $fetchdata = $statement->fetch();


    
    $_SESSION['Fullname'] = $fetchdata['firstname'] . " " . $fetchdata['lastname'];
    $_SESSION['qrlink'] = $fetchdata['qrlink'];
    $_SESSION['seatcode'] = $varSeatCode;

    header("location:certView.php");

}










?>